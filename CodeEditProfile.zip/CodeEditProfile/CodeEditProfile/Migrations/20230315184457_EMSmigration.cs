﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CodeEditProfile.Migrations
{
    public partial class EMSmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
