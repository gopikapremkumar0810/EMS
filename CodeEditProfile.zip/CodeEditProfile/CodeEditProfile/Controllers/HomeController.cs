﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CodeEditProfile.Models;
using CodeEditProfile.Context;
using Microsoft.AspNetCore.Http;

namespace CodeEditProfile.Controllers
{
    public class HomeController : Controller
    {
        private EmployeeDbContext _context;
        public HomeController(EmployeeDbContext context)
        {
            this._context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(string Uname, string Pass)
        {
            if (string.IsNullOrEmpty(Uname) | string.IsNullOrEmpty(Pass))
            {
                string UNameval = "Required";
            }
            else
            {
                var user = _context.Employees.Where(e => e.Email == Uname).ToList();
                HttpContext.Session.Clear();
                HttpContext.Session.SetString("User", user[0].Email);
                if (user.Count > 0)
                {
                    return RedirectToAction("ViewProfile", "Home");
                }
            }
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(EmployeeDetails users)  //[Bind(Include = "Id")]
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Add(users);
                    _context.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (Exception e)
            {
            }

            return View(users);
        }

        public IActionResult ViewProfile(string EmailID)
        {
            EmailID=HttpContext.Session.GetString("User");
            var user = _context.Employees.Where(e => e.Email == EmailID).FirstOrDefault();
            return View(user);
        }

        public IActionResult Edit(string EmailID)
        {
            EmailID = HttpContext.Session.GetString("User");
            var user = _context.Employees.Where(e => e.Email == EmailID).FirstOrDefault();
            return View(user);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(EmployeeDetails users)  //[Bind(Include = "Id")]
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string EmailID = HttpContext.Session.GetString("User");
                    var user = _context.Employees.Where(e => e.Email == EmailID).ToList();
                    if (user.Count > 0)
                    {
                        user[0].Name = users.Name;
                        user[0].PancardAttachment = users.PancardAttachment;
                        user[0].Password = users.Password;
                        user[0].ConfirmPassword = users.ConfirmPassword;
                        user[0].Address = users.Address;
                        user[0].AdharcardNumber = users.AdharcardNumber;
                        user[0].PancardNumber = users.PancardNumber;
                        user[0].Signature = users.Signature;
                        user[0].State = users.State;
                        user[0].City = users.City;
                        user[0].Age = users.Age;
                        user[0].Photo = users.Photo;

                    }
                    _context.Update(user);
                    _context.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (Exception e)
            {
            }

            return View(users);
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
