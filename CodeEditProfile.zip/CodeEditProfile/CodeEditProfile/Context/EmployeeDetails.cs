﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeEditProfile.Context
{
    public class EmployeeDetails
    {
        public int EmployeeDetailsId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Age { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string PancardNumber { get; set; }
        public string AdharcardNumber { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string PancardAttachment { get; set; }
        public string AdharcardAttachment { get; set; }
        public string Photo { get; set; }
        public string Signature { get; set; }
    }
}
